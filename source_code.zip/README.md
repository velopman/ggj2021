# godot-template
Template project to be used as a base for creating a new project in Godot
